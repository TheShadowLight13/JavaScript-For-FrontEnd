function multiplyNumberByTwo(nums) {
    let number = Number(nums[0]);
    return number * 2;
}

let input = ["2"];
let result = multiplyNumberByTwo(input);
console.log(result);


