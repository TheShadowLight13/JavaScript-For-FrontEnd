function printNumbers(n) {
    let numbers = Number(n[0]);
    for (let i = 1; i <= numbers; i++) {
        console.log(i);
    }
}

let input = ["5"];
printNumbers(input);