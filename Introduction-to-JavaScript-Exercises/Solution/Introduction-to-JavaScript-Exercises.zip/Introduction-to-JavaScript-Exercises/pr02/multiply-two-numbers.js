function multiplyTwoNumbers(nums) {
    let x = Number(nums[0]);
    let y = Number(nums[1]);
    return x * y;
}

let input = ["2", "3"];
let result = multiplyTwoNumbers(input);
console.log(result);

